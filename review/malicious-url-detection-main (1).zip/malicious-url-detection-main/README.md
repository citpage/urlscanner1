# Malicious URLs detector

This project classifies and detect malicious URLs using Machine Learning in a web application built with Flask and Next.js

![Logo](./demo/benign.png)
![Logo](./demo/phishing.png)
![Logo](./demo/defacement.png)
